{{-- Simple page for showing the exam instructions before commencement. The instructions are hardcoded. The page also displays the time the subject will take, the name of the subject etc --}}
